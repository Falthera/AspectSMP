"""Chiptune synth engine for the Aspect SMP soundtrack (numpy/scipy only)."""
import numpy as np
from scipy.signal import fftconvolve, lfilter

SR = 44100
RNG = np.random.default_rng(1337)

MAJOR = [0, 2, 4, 5, 7, 9, 11]
MINOR = [0, 2, 3, 5, 7, 8, 10]
PC = {"C": 0, "Db": 1, "D": 2, "Eb": 3, "E": 4, "F": 5, "Gb": 6, "G": 7, "Ab": 8, "A": 9, "Bb": 10, "B": 11}


def mtof(m):
    return 440.0 * 2 ** ((m - 69) / 12.0)


def degree_to_midi(root_pc, mode, deg, octave=4):
    """Scale degree (may be negative / >6) to MIDI note."""
    scale = MAJOR if mode == "major" else MINOR
    o, d = divmod(int(deg), 7)
    return 12 * (octave + 1) + root_pc + scale[d] + 12 * o


# ---------------------------------------------------------------- envelopes
def adsr(n, a=0.005, d=0.05, s=0.8, r=0.05):
    a_n, d_n, r_n = int(a * SR), int(d * SR), int(r * SR)
    a_n = max(a_n, 1)
    env = np.ones(n)
    if a_n + d_n + r_n > n:
        scale = n / float(a_n + d_n + r_n + 1)
        a_n, d_n, r_n = max(int(a_n * scale), 1), int(d_n * scale), int(r_n * scale)
    env[:a_n] = np.linspace(0, 1, a_n)
    env[a_n:a_n + d_n] = np.linspace(1, s, d_n) if d_n else env[a_n:a_n + d_n]
    sus_end = n - r_n
    env[a_n + d_n:sus_end] = s
    if r_n:
        env[sus_end:] = np.linspace(s, 0, n - sus_end)
    return env


def expdecay(n, tau):
    return np.exp(-np.arange(n) / (tau * SR))


# ---------------------------------------------------------------- oscillators
def _phase(freq, n):
    if np.isscalar(freq):
        freq = np.full(n, float(freq))
    return np.cumsum(freq / SR) % 1.0


def pulse(freq, n, duty=0.25, vib=0.0, vib_rate=5.5, pitch_bend=0.0):
    t = np.arange(n) / SR
    f = np.full(n, float(freq)) if np.isscalar(freq) else freq
    if vib:
        f = f * (1 + vib * np.sin(2 * np.pi * vib_rate * t) * np.minimum(t / 0.15, 1))
    if pitch_bend:
        f = f * 2 ** (pitch_bend * t / max(t[-1], 1e-3) / 12.0)
    ph = np.cumsum(f / SR) % 1.0
    d = duty if not np.isscalar(duty) else np.full(n, duty)
    return np.where(ph < d, 1.0, -1.0) * 0.5


def triangle(freq, n, vib=0.0, steps=16):
    t = np.arange(n) / SR
    f = np.full(n, float(freq))
    if vib:
        f = f * (1 + vib * np.sin(2 * np.pi * 5 * t))
    ph = np.cumsum(f / SR) % 1.0
    tri = 2 * np.abs(2 * ph - 1) - 1
    return np.round(tri * (steps / 2)) / (steps / 2) * 0.6  # 4-bit NES staircase


def sine(freq, n, vib=0.0):
    t = np.arange(n) / SR
    f = np.full(n, float(freq))
    if vib:
        f = f * (1 + vib * np.sin(2 * np.pi * 5 * t))
    return np.sin(2 * np.pi * np.cumsum(f / SR))


def saw(freq, n):
    ph = _phase(freq, n)
    return 2 * ph - 1


_LOOP93 = np.random.default_rng(93).choice([-1.0, 1.0], 93)
_LOOP31 = np.random.default_rng(31).choice([-1.0, 1.0], 31)


def noise(n, rate=8000.0, looped=False, short=False):
    """NES-style noise. looped=True -> short LFSR 'metallic' mode."""
    idx = (np.arange(n) * rate / SR).astype(np.int64)
    if looped:
        pat = _LOOP31 if short else _LOOP93
        return pat[idx % len(pat)] * 0.5
    base = RNG.choice([-1.0, 1.0], idx.max() + 2)
    return base[idx] * 0.5


# ---------------------------------------------------------------- instruments
def lowpass(x, cutoff):
    a = np.exp(-2 * np.pi * cutoff / SR)
    return lfilter([1 - a], [1, -a], x)


def v_piano(m, n, lowcut=False):
    f = mtof(m)
    t = np.arange(n) / SR
    out = np.zeros(n)
    for h, amp in enumerate([1, .55, .35, .22, .14, .09], start=1):
        if f * h < SR / 2.2:
            out += amp * np.sin(2 * np.pi * f * h * t + 0.3 * h) * np.exp(-t * (1.6 + 0.9 * h) / max(1.2, 1))
    out *= adsr(n, 0.004, 0.0, 1.0, 0.04)
    if lowcut:
        out = lowpass(out, 1800)
    return out * 0.5


def v_bell(m, n, tubular=False):
    f = mtof(m)
    t = np.arange(n) / SR
    ratios = [1, 2.0, 2.76, 5.4, 8.93] if tubular else [1, 2.76, 5.4, 8.93, 13.3]
    amps = [1, .6, .45, .25, .12]
    out = np.zeros(n)
    for r, a in zip(ratios, amps):
        if f * r < SR / 2.2:
            out += a * np.sin(2 * np.pi * f * r * t) * np.exp(-t * (1.1 + 0.8 * r) / (2.5 if tubular else 1.6))
    return out * 0.35


def v_vibes(m, n):
    f = mtof(m)
    t = np.arange(n) / SR
    out = np.sin(2 * np.pi * f * t) + 0.3 * np.sin(2 * np.pi * f * 4 * t) * np.exp(-t * 6)
    out *= np.exp(-t * 1.2) * (1 + 0.25 * np.sin(2 * np.pi * 5.5 * t))
    return out * 0.45


def v_pluck(m, n):
    f = mtof(m)
    t = np.arange(n) / SR
    out = saw(f, n) * np.exp(-t * 14)
    return lowpass(out, 2500) * 0.45


def v_strings(m, n, att=0.25, rel=0.4):
    f = mtof(m)
    out = np.zeros(n)
    t = np.arange(n) / SR
    for det in (-0.07, 0.0, 0.07):
        out += saw(f * 2 ** (det / 12), n)
    out = lowpass(out / 3, 2200) * (1 + 0.1 * np.sin(2 * np.pi * 5.2 * t))
    return out * adsr(n, att, 0.1, 0.85, rel) * 0.5


def v_cello_trem(m, n):
    f = mtof(m)
    t = np.arange(n) / SR
    out = lowpass(saw(f, n), 1200) * (0.65 + 0.35 * np.sin(2 * np.pi * 9 * t))
    return out * adsr(n, 0.3, 0.1, 0.9, 0.5) * 0.5


def v_choir(m, n, att=0.35, rel=0.6):
    f = mtof(m)
    t = np.arange(n) / SR
    vib = 1 + 0.006 * np.sin(2 * np.pi * 5.3 * t) * np.minimum(t / 0.5, 1)
    ph = np.cumsum(f * vib / SR)
    out = np.zeros(n)
    h = 1
    while f * h < 4500:
        fh = f * h
        w = np.exp(-((fh - 750) / 350) ** 2) + 0.6 * np.exp(-((fh - 1150) / 300) ** 2) + 0.2 * np.exp(-((fh - 2600) / 500) ** 2)
        out += (w + 0.04 / h) * np.sin(2 * np.pi * ph * h)
        h += 1
    return out / max(np.abs(out).max(), 1e-6) * adsr(n, att, 0.1, 0.85, rel) * 0.5


def v_brass(m, n, stab=False, att=0.04, rel=0.12):
    f = mtof(m)
    out = saw(f, n) + 0.6 * saw(f * 1.004, n)
    env = adsr(n, att, 0.08, 0.75, rel)
    brightness = np.minimum(np.arange(n) / (0.12 * SR), 1)
    lo = lowpass(out, 900)
    hi = lowpass(out, 3800)
    out = lo * (1 - brightness) + hi * brightness
    return out * env * 0.4


def v_horn(m, n):
    f = mtof(m)
    return lowpass(saw(f, n), 1400) * adsr(n, 0.08, 0.1, 0.8, 0.2) * 0.5


def v_trumpet(m, n):
    f = mtof(m)
    t = np.arange(n) / SR
    out = pulse(f * (1 + 0.004 * np.sin(2 * np.pi * 5.5 * t)), n, 0.35) + saw(f, n) * 0.5
    return lowpass(out, 3200) * adsr(n, 0.03, 0.06, 0.8, 0.1) * 0.5


def v_clarinet(m, n):
    f = mtof(m)
    t = np.arange(n) / SR
    ph = np.cumsum(f * (1 + 0.007 * np.sin(2 * np.pi * 5 * t)) / SR)
    out = sum(np.sin(2 * np.pi * ph * h) / h for h in (1, 3, 5, 7))
    return out * adsr(n, 0.04, 0.05, 0.85, 0.1) * 0.35


def v_celesta(m, n):
    f = mtof(m)
    t = np.arange(n) / SR
    out = np.sin(2 * np.pi * f * t) + 0.4 * np.sin(2 * np.pi * f * 4 * t) * np.exp(-t * 8)
    return out * np.exp(-t * 1.5) * 0.4


def v_music_box(m, n):
    f = mtof(m)
    t = np.arange(n) / SR
    out = np.sin(2 * np.pi * f * t) + 0.5 * np.sin(2 * np.pi * f * 3 * t) * np.exp(-t * 4) + 0.2 * np.sin(2 * np.pi * f * 6.01 * t) * np.exp(-t * 9)
    return out * np.exp(-t * 3.0) * 0.4


# ---------------------------------------------------------------- drums
def d_kick(n=None, pitch=1.0):
    n = n or int(0.16 * SR)
    t = np.arange(n) / SR
    f = 150 * pitch * np.exp(-t * 35) + 45
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 18) * 0.9


def d_noise_kick(n=None):
    n = n or int(0.13 * SR)
    t = np.arange(n) / SR
    return (np.sign(np.sin(2 * np.pi * np.cumsum(120 * np.exp(-t * 30) + 40) / SR)) * 0.5) * np.exp(-t * 22)


def d_snare(looped=True, pitch=1.0):
    n = int(0.14 * SR)
    t = np.arange(n) / SR
    return noise(n, 11000 * pitch, looped=looped) * np.exp(-t * 28) * 0.9


def d_hat(n=None, open_=False, rate=24000):
    n = n or int((0.12 if open_ else 0.035) * SR)
    t = np.arange(n) / SR
    return noise(n, rate, looped=True, short=True) * np.exp(-t * (14 if open_ else 90)) * 0.55


def d_metal(rate=6000):
    n = int(0.09 * SR)
    t = np.arange(n) / SR
    return noise(n, rate, looped=True, short=True) * np.exp(-t * 26) * 0.7


def d_tom(freq=110):
    n = int(0.25 * SR)
    t = np.arange(n) / SR
    f = freq * (1 + 0.8 * np.exp(-t * 18))
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 10) * 0.8


def d_timpani(freq=80):
    n = int(0.6 * SR)
    t = np.arange(n) / SR
    f = freq * (1 + 0.3 * np.exp(-t * 20))
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 5) * 0.8


def d_crash():
    n = int(1.5 * SR)
    t = np.arange(n) / SR
    return noise(n, 30000) * np.exp(-t * 3) * 0.4


# ---------------------------------------------------------------- mixing
class Track:
    def __init__(self, seconds, tail=4.0):
        self.L = int(round(seconds * SR))
        self.total = self.L + int(tail * SR)
        self.layers = {}  # name -> dict(buf_l, buf_r, rev, delay)

    def layer(self, name, pan=0.0, rev=0.0, delay=0.0, gain=1.0):
        if name not in self.layers:
            self.layers[name] = dict(buf=np.zeros(self.total, dtype=np.float32), pan=pan, rev=rev, delay=delay, gain=gain)
        return self.layers[name]

    def add(self, name, t_sec, sig, vel=1.0):
        buf = self.layers[name]["buf"]
        s = int(t_sec * SR)
        if s >= self.total or s < 0:
            return
        e = min(s + len(sig), self.total)
        buf[s:e] += sig[: e - s] * vel

    def render(self, ir_len=3.2, reverb_mix=1.0):
        left = np.zeros(self.total, dtype=np.float32)
        right = np.zeros(self.total, dtype=np.float32)
        wet = np.zeros(self.total, dtype=np.float32)
        for lay in self.layers.values():
            buf = lay["buf"] * lay["gain"]
            if lay["delay"]:
                d = int(0.33 * SR)
                echo = np.zeros_like(buf)
                for k, g in enumerate((0.45, 0.22, 0.1), start=1):
                    echo[k * d:] += buf[:-k * d] * g * lay["delay"]
                buf = buf + echo
            p = (lay["pan"] + 1) / 2
            left += (buf * np.cos(p * np.pi / 2)).astype(np.float32)
            right += (buf * np.sin(p * np.pi / 2)).astype(np.float32)
            wet += (buf * lay["rev"]).astype(np.float32)
            lay["buf"] = None
        if wet.any():
            n_ir = int(ir_len * SR)
            tt = np.arange(n_ir) / SR
            irs = []
            for seed in (11, 12):
                r = np.random.default_rng(seed).standard_normal(n_ir) * np.exp(-tt / (ir_len / 5.5))
                r = lowpass(r, 5500)
                r[: int(0.02 * SR)] *= np.linspace(0, 1, int(0.02 * SR))
                irs.append(r / np.sqrt(np.sum(r ** 2)) * 0.6)
            left += (fftconvolve(wet, irs[0].astype(np.float32))[: self.total] * reverb_mix).astype(np.float32)
            right += (fftconvolve(wet, irs[1].astype(np.float32))[: self.total] * reverb_mix).astype(np.float32)
        return np.stack([left, right], axis=1)


def fold_loop(stereo, L):
    out = stereo[:L].copy()
    tail = stereo[L:]
    out[: len(tail)] += tail[: L]
    return out
