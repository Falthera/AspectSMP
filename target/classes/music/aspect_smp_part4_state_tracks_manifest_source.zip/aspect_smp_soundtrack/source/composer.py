"""Rule-based composer: turns a track config into stereo audio using the leitmotif DNA."""
import math
import zlib
import numpy as np
from engine import *  # noqa

# Leitmotif DNA: 4 bars (16 beats). Cell = quarter, eighth, quarter, eighth, dotted-quarter.
BASE = [(0, 1), (2, .5), (4, 1), (2, .5), (3, 1.5), (2, 1), (1, 1), (0, 1.5),
        (0, 1), (2, .5), (4, 1), (2, .5), (5, 1.5), (4, 1), (2, 1), (0, 1.5)]
PROG = {"minor": [0, 5, 2, 6], "major": [0, 5, 2, 3]}  # i-VI-III-VII / I-vi-iii-IV


def motif(leit):
    if leit == "waterfall":
        return [(d, du * 2) for d, du in BASE], 32
    if leit == "core":
        return [(-d, du) for d, du in BASE], 16
    if leit == "metal":
        return [(d if i % 2 == 0 else 0, du / 2) for i, (d, du) in enumerate(BASE)] * 2, 16
    return list(BASE), 16


RING = {"piano": 1.8, "glock": 3.0, "tubular": 3.5, "vibes": 2.2, "pluck": 0.35, "celesta": 2.5, "musicbox": 2.5}
PULSE_DUTY = {"p125": .125, "p25": .25, "p50": .5, "sq": .5}
_cache = {}


def synth(voice, midi, dur, L, f0=0.0, f1=0.0):
    ring = RING.get(voice, 0)
    n = max(int(max(dur, ring) * SR), 128)
    nd = max(int(dur * SR), 128)
    cents = L.get("detune", 0)
    m = midi + cents / 100.0
    f = mtof(m)
    if voice in PULSE_DUTY:
        duty = PULSE_DUTY[voice]
        curve = L.get("duty_curve")
        if curve:
            xs = [c[0] for c in curve]
            ys = [c[1] for c in curve]
            duty = np.linspace(np.interp(f0, xs, ys), np.interp(f1, xs, ys), nd)
        if L.get("lfo"):
            t = np.arange(nd) / SR
            base = duty if not np.isscalar(duty) else np.full(nd, duty)
            duty = np.clip(base + L.get("lfo_depth", .1) * np.sin(2 * np.pi * L["lfo"] * t), .06, .6)
        sig = pulse(f, nd, duty, vib=L.get("vib", 0), pitch_bend=L.get("bend", 0))
        sig = sig * adsr(nd, L.get("att", .004), .06, L.get("sus", .75), L.get("rel", .04)) * 0.7
        return sig
    if voice == "tri":
        return triangle(f, nd, vib=L.get("vib", 0)) * adsr(nd, .003, .02, .95, .03)
    if voice == "sine":
        return sine(f, nd, vib=L.get("vib", 0)) * adsr(nd, L.get("att", .02), .05, .9, L.get("rel", .08)) * 0.6
    if voice == "piano":
        return v_piano(midi, n, lowcut=L.get("lowcut", False))
    if voice == "glock":
        return v_bell(midi, n)
    if voice == "tubular":
        return v_bell(midi, n, tubular=True)
    if voice == "vibes":
        return v_vibes(midi, n)
    if voice == "pluck":
        return v_pluck(midi, n)
    if voice == "celesta":
        return v_celesta(midi, n)
    if voice == "musicbox":
        return v_music_box(midi, n)
    if voice == "strings":
        return v_strings(midi, nd, att=L.get("att", .25), rel=L.get("rel", .4))
    if voice == "cello":
        return v_cello_trem(midi, nd)
    if voice == "choir":
        return v_choir(midi, nd, att=L.get("att", .35), rel=L.get("rel", .6))
    if voice == "brass":
        return v_brass(midi, nd, att=L.get("att", .04))
    if voice == "horn":
        return v_horn(midi, nd)
    if voice == "trumpet":
        return v_trumpet(midi, nd)
    if voice == "clarinet":
        return v_clarinet(midi, nd)
    raise ValueError(voice)


def drum(kind, pitch=1.0):
    key = (kind, round(pitch, 3))
    if key not in _cache:
        fn = {
            "kick": lambda: d_kick(pitch=pitch),
            "nkick": lambda: d_noise_kick(),
            "snare": lambda: d_snare(looped=False, pitch=pitch),
            "nsnare": lambda: d_snare(looped=True, pitch=pitch),
            "hat": lambda: d_hat(),
            "ohat": lambda: d_hat(open_=True),
            "metal": lambda: d_metal(),
            "metal2": lambda: d_metal(9000),
            "tom": lambda: d_tom(110 * pitch),
            "tom2": lambda: d_tom(160 * pitch),
            "timp": lambda: d_timpani(80 * pitch),
            "crash": lambda: d_crash(),
        }[kind]
        _cache[key] = fn()
    return _cache[key]


def build_bars(cfg):
    dur = cfg["dur"]
    bpm = cfg["bpm"]
    meter = []
    for nb, bpb in cfg.get("meter", []):
        meter += [bpb] * nb
    default_bpb = cfg.get("bpb", 4)
    leit_len = motif(cfg.get("leit", "spear"))[1]
    cyc_default = leit_len * default_bpb // math.gcd(leit_len, default_bpb) if default_bpb != 4 else leit_len
    cyc = cfg.get("cyc", cyc_default)
    bars = []
    b = 0.0
    t = 0.0
    ends = []
    i = 0
    while t < dur * 1.3 + 4:
        bpb = meter[i] if i < len(meter) else default_bpb
        cur = bpm if np.isscalar(bpm) else bpm[0] + (bpm[1] - bpm[0]) * min(t / dur, 1.0)
        spb = 60.0 / cur
        bars.append((b, bpb, t, spb))
        b += bpb
        t += bpb * spb
        i += 1
        ends.append((i, b, t))
    best = None
    for tol, c in ((0.15, cyc), (0.25, cyc), (0.2, 16), (0.3, 4)):
        cands = [e for e in ends if abs(e[2] - dur) <= tol * dur and e[1] % c == 0]
        if cands:
            best = min(cands, key=lambda e: abs(e[2] - dur))
            break
    if best is None:
        best = min(ends, key=lambda e: abs(e[2] - dur))
    nb, total_beats, L = best
    return bars[:nb], total_beats, L


def compose(cfg, layers=None, one_shot=None):
    layers = layers if layers is not None else cfg["layers"]
    root = PC[cfg["root"]]
    mode = cfg["mode"]
    loop = cfg.get("loop", True)
    bars, total_beats, L_sec = build_bars(cfg)
    if not loop:
        L_sec = cfg["dur"]
    b0s = np.array([b[0] for b in bars])
    seed0 = zlib.crc32(cfg["name"].encode())
    leit = cfg.get("leit", "spear")
    prog = PROG[mode]

    def T(beat):
        i = int(np.clip(np.searchsorted(b0s, beat, side="right") - 1, 0, len(bars) - 1))
        bb, bpb, tt, spb = bars[i]
        return tt + (beat - bb) * spb

    tr = Track(L_sec, tail=cfg.get("tail", 4.0))
    free = cfg.get("free", False)
    dp = 2 ** (cfg.get("dpitch", 0) / 12.0)

    def frac(t):
        return t / L_sec

    def lay_gain(lay, f):
        acts = lay.get("act")
        if acts and not any(a <= f < b for a, b in acts):
            return 0.0
        g = 1.0
        gc = lay.get("gain_curve")
        if gc:
            g = float(np.interp(f, [c[0] for c in gc], [c[1] for c in gc]))
        return g

    for li, lay in enumerate(layers):
        lname = f"{li}_{lay['role']}_{lay.get('voice', '')}"
        tr.layer(lname, pan=lay.get("pan", 0), rev=lay.get("rev", 0.0), delay=lay.get("delay", 0), gain=lay.get("gain", 1.0))
        rng = np.random.default_rng(seed0 + li * 7919)
        role = lay["role"]
        voice = lay.get("voice", "p25")
        oct_ = lay.get("oct", 4)

        def put(t, sig, f, vel=1.0):
            g = lay_gain(lay, f)
            if g > 0:
                tr.add(lname, t, sig, vel * g)

        def note(deg, octv, beat, dbeats, vel=1.0, semis=0):
            m = degree_to_midi(root, mode, deg, octv) + semis + lay.get("shift", 0)
            t0 = T(beat)
            if free:
                t0 += rng.normal(0, cfg.get("jitter", 0.06))
                t0 = max(t0, 0)
            t1 = T(beat + dbeats * lay.get("legato", 0.92))
            f0, f1 = frac(t0), frac(t1)
            if lay_gain(lay, f0) <= 0:
                return
            sig = synth(voice, m, max(t1 - t0, 0.02), lay, f0, f1)
            put(t0, sig, f0, vel)

        if role in ("melody", "counter_motif"):
            seq, _ = motif(leit)
            sp = lay.get("speed", 1.0)
            delay_b = lay.get("delay_beats", 0.0)
            b = 0.0
            k = 0
            while b < total_beats:
                for d, du in seq:
                    du2 = du / sp
                    if b >= total_beats:
                        break
                    semis = lay.get("dis", 0) if (k % 3 == 2) else 0
                    note(d + lay.get("harm", 0), oct_ + (1 if role == "counter_motif" else 0), b + delay_b, du2, vel=lay.get("vel", 1.0), semis=semis)
                    b += du2
                    k += 1
        elif role == "counter":
            pats = [[0, .5, 1.5, 2, 3, 3.5], [0.5, 1, 2, 2.5, 3.5], [0, 1, 1.5, 2.5, 3]]
            for i, (bb, bpb, tt, spb) in enumerate(bars):
                r = prog[i % 4]
                tones = [r + 2, r + 4, r + 7, r + 9, r + 4]
                pat = pats[i % 3]
                for j, off in enumerate(pat):
                    if off < bpb:
                        note(tones[(i + j) % len(tones)], oct_, bb + off, 0.5, vel=lay.get("vel", .8))
        elif role == "bass":
            style = lay.get("style", "eighths")
            for i, (bb, bpb, tt, spb) in enumerate(bars):
                r = prog[i % 4]
                if style == "eighths":
                    for k in range(int(bpb * 2)):
                        note(r + (7 if k % 4 == 3 else 0), oct_ if k % 2 == 0 else oct_ + 1 if lay.get("pop") else oct_, bb + k * .5, .5, vel=.9)
                elif style == "quarters":
                    for k in range(int(bpb)):
                        note(r, oct_, bb + k, 1.0, vel=.9)
                elif style == "drive":
                    for k in range(int(bpb * 2)):
                        note(r + (4 if (k == int(bpb * 2) - 1 and i % 2) else 0), oct_, bb + k * .5, .5, vel=1.0 if k % 2 == 0 else .75)
                elif style == "half":
                    note(r, oct_, bb, bpb / 2.0, vel=.9)
                    note(r + 4, oct_, bb + bpb / 2.0, bpb / 2.0, vel=.8)
                elif style == "sustain":
                    note(r, oct_, bb, bpb * lay.get("hold", 1.0), vel=.9)
                elif style == "waltz":
                    note(r, oct_, bb, 1.0, vel=1.0)
                    for k in range(1, int(bpb)):
                        note(r + 4, oct_ + 1, bb + k, 1.0, vel=.6)
        elif role == "arp":
            step = lay.get("step", .25)
            for i, (bb, bpb, tt, spb) in enumerate(bars):
                r = prog[i % 4]
                tones = [r, r + 2, r + 4, r + 7]
                seq = tones + tones[-2:0:-1]
                for k in range(int(bpb / step)):
                    note(seq[k % len(seq)], oct_, bb + k * step, step, vel=.7)
        elif role == "pad":
            for i, (bb, bpb, tt, spb) in enumerate(bars):
                r = prog[i % 4]
                for dgr in (r, r + 2, r + 4):
                    note(dgr, oct_, bb, bpb * 1.04, vel=lay.get("vel", .6))
        elif role == "drone":
            span = lay.get("span", 2)
            for i in range(0, len(bars), span):
                bb, bpb, tt, spb = bars[i]
                end_i = min(i + span, len(bars))
                nb_beats = sum(b[1] for b in bars[i:end_i]) + 1.0 / spb * 1.2
                r = prog[(i // span) % 4] if lay.get("moving") else 0
                for k, (dg, cents) in enumerate([(r, -10), (r, 10), (r + 4, 0)]):
                    lay["detune"] = cents
                    note(dg, oct_, bb, nb_beats, vel=lay.get("vel", .6) * (0.6 if k == 2 else 1.0))
                if lay.get("dis"):
                    lay["detune"] = 0
                    m = degree_to_midi(root, mode, r, oct_) + lay.get("dis_semis", 1)
                    t0 = T(bb)
                    f0 = frac(t0)
                    sig = synth(voice, m, T(bb + nb_beats) - t0, lay, f0, f0)
                    put(t0, sig, f0, .4)
            lay["detune"] = 0
        elif role == "perc":
            style = lay.get("style", "rock")
            nes = lay.get("nes", True)
            K, S, H = ("nkick", "nsnare", "hat") if nes else ("kick", "snare", "hat")
            for i, (bb, bpb, tt, spb) in enumerate(bars):
                def hit(off, kind, vel):
                    t0 = T(bb + off)
                    f = frac(t0)
                    put(t0, drum(kind, dp), f, vel)
                if style == "rock":
                    if bpb == 4:
                        for o in (0, 2, 2.5 if i % 2 else 3.5):
                            hit(o, K, 1.0)
                        hit(1, S, .9)
                        hit(3, S, .9)
                    elif bpb == 3:
                        hit(0, K, 1.0)
                        hit(1, S, .7)
                        hit(2, S, .7)
                    else:
                        hit(0, K, 1.0)
                        hit(1, S, .9)
                    for k in range(int(bpb * 2)):
                        hit(k * .5, H, .5 if k % 2 else .7)
                elif style == "drive":
                    for k in range(int(bpb)):
                        hit(k, K, 1.0 if k % 2 == 0 else .8)
                    for o in range(1, int(bpb), 2):
                        hit(o, S, .95)
                    for k in range(int(bpb * 4)):
                        hit(k * .25, H, .35 if k % 2 else .6)
                    if i % 4 == 3:
                        hit(bpb - .5, "tom", .8)
                        hit(bpb - .25, "tom2", .8)
                elif style == "metal":
                    st = lay.get("step", .5)
                    for k in range(int(bpb / st)):
                        hit(k * st, "metal" if k % 2 == 0 else "metal2", .9 if k % 4 == 0 else .55)
                    hit(0, K, 1.0)
                    if bpb >= 2:
                        hit(bpb / 2.0, S, .9)
                elif style == "timp":
                    hit(0, "timp", 1.0)
                    if bpb == 4:
                        hit(2, "timp", .7)
                    if i % 4 == 3:
                        for k in range(4):
                            hit(bpb - 1 + k * .25, "tom" if k % 2 else "tom2", .6 + k * .1)
                elif style == "sparse":
                    hit(0, K, .8)
                    if rng.random() < .6:
                        hit(float(rng.integers(1, max(int(bpb), 2))) + .5, "metal", .5)
                elif style == "heart":
                    hit(0, K, 1.0)
                    hit(0.38, K, .7)
                elif style == "accel":
                    stp = float(np.interp(tt / L_sec, [0, 1], [.5, .125]))
                    hit(0, K, 1.0)
                    for k in range(int(bpb / stp)):
                        hit(k * stp, H, .6)
        elif role == "harmonics":
            base = degree_to_midi(root, mode, 0, oct_)
            for k in range(1, 9):
                bt = (k - 1) * total_beats / 9.0
                m = base + 12 * math.log2(k)
                t0 = T(bt)
                f0 = frac(t0)
                sig = synth(voice, m, T(total_beats) - t0, lay, f0, f0)
                put(t0, sig, f0, lay.get("vel", .6))
        elif role == "seq":
            b = lay.get("start", 0.0)
            items = lay["items"]
            for k, (d, du) in enumerate(items):
                last = k == len(items) - 1
                note(d, oct_, b, du * (1.0 if not last else 1.0), vel=lay.get("vel", 1.0) * (1.0 if not last else 1.1))
                b += du
        elif role == "stab":
            for i, (bb, bpb, tt, spb) in enumerate(bars):
                r = prog[i % 4]
                offs = [0] + ([2.5] if bpb == 4 and lay.get("syn", True) else [])
                for off in offs:
                    for dg in (r, r + 2, r + 4):
                        note(dg, oct_, bb + off, .35, vel=.7)
        elif role == "bells":
            seq, _ = motif(leit)
            prob = lay.get("prob", .5)
            b = 0.0
            while b < total_beats:
                for d, du in seq:
                    if b >= total_beats:
                        break
                    if rng.random() < prob:
                        note(d + lay.get("harm", 0), oct_, b, du, vel=lay.get("vel", .8))
                    b += du
        elif role == "chord_bells":
            for i, (bb, bpb, tt, spb) in enumerate(bars):
                r = prog[i % 4]
                for k, dg in enumerate((r, r + 2, r + 4, r + 7)):
                    if rng.random() < lay.get("prob", .8):
                        note(dg, oct_, bb + k * lay.get("step", .5), 1.0, vel=.7)
        elif role == "glitch":
            for i, (bb, bpb, tt, spb) in enumerate(bars):
                for _ in range(int(rng.integers(lay.get("min", 0), lay.get("max", 3) + 1))):
                    off = float(rng.integers(0, int(bpb * 4))) / 4.0
                    dg = int(rng.integers(0, 10))
                    for c in (-10, 10):
                        lay["detune"] = c
                        m = degree_to_midi(root, mode, dg, oct_)
                        t0 = T(bb + off)
                        f0 = frac(t0)
                        sig = synth(voice, m, float(rng.uniform(.03, .1)), lay, f0, f0)
                        put(t0, sig, f0, .5)
                lay["detune"] = 0
        elif role == "fx":
            kind = lay["kind"]
            for i, (bb, bpb, tt, spb) in enumerate(bars):
                bar_len = bpb * spb
                cnt = int(rng.poisson(lay.get("rate", 1.0)))
                for _ in range(cnt):
                    t0 = tt + float(rng.uniform(0, bar_len))
                    f0 = frac(t0)
                    if kind == "lava":
                        n = int(rng.uniform(.05, .18) * SR)
                        sig = lowpass(noise(n, float(rng.uniform(900, 2800)), looped=True), 1400) * expdecay(n, .05) * 1.4
                    elif kind == "ghast":
                        n = int(rng.uniform(1.2, 2.2) * SR)
                        tt_ = np.arange(n) / SR
                        fr = np.linspace(260, 85, n) * (1 + .03 * np.sin(2 * np.pi * 7 * tt_))
                        sig = (np.sign(np.sin(2 * np.pi * np.cumsum(fr) / SR)) * .3 + lowpass(RNG.standard_normal(n), 500) * .5)
                        sig = lowpass(sig, 1100) * adsr(n, .1, .2, .6, .8) * 1.2
                    elif kind == "wind":
                        n = int(rng.uniform(2.5, 4.5) * SR)
                        sig = lowpass(RNG.standard_normal(n), 700) * np.sin(np.linspace(0, np.pi, n)) ** 2 * 0.9
                    elif kind == "thunder":
                        n = int(rng.uniform(2.0, 3.5) * SR)
                        sig = lowpass(RNG.standard_normal(n), 180) * expdecay(n, .8) * 4.0
                    elif kind == "chimes":
                        n = int(rng.uniform(.3, .7) * SR)
                        sig = noise(n, 22000, looped=True, short=True) * expdecay(n, .12) * .6
                        sig += v_bell(int(rng.integers(88, 100)), n) * .8
                    elif kind == "click":
                        sig = drum("metal", 1.0)
                    else:
                        continue
                    put(t0, sig, f0, lay.get("vel", 1.0))
        else:
            raise ValueError(role)

    stereo = tr.render(ir_len=cfg.get("ir", 3.2), reverb_mix=cfg.get("rev_mix", 1.0))
    if cfg.get("lp"):
        for ch in range(2):
            stereo[:, ch] = lowpass(stereo[:, ch], cfg["lp"])
    if cfg.get("crush"):
        q = 2 ** cfg["crush"]
        hold = cfg.get("hold", 3)
        idx = (np.arange(len(stereo)) // hold) * hold
        stereo = np.round(stereo[idx] * q / 2) / (q / 2)
    if loop:
        out = fold_loop(stereo, tr.L)
    else:
        out = stereo[: tr.L].copy()
        fo = int(cfg.get("fadeout", 0.4) * SR)
        out[-fo:] *= np.linspace(1, 0, fo)[:, None]
    if cfg.get("fadeout_loop"):
        pass
    return out.astype(np.float32), dict(bars=len(bars), beats=total_beats, seconds=tr.L / SR, samples=tr.L)
