"""All Aspect SMP track definitions. Names match the spec exactly (mus_aspectsmp_*)."""


def Ly(role, voice="p25", **kw):
    d = dict(role=role, voice=voice)
    d.update(kw)
    return d


TRACKS = []


def T(name, root, mode, bpm, dur, layers, **kw):
    cfg = dict(name="mus_aspectsmp_" + name, root=root, mode=mode, bpm=bpm, dur=dur, layers=layers)
    cfg.update(kw)
    TRACKS.append(cfg)
    return cfg


ASPECT_DUR = 112
EVENT_DUR = 52

# ---------------------------------------------------------------- 1-4 core tracks
T("main_theme", "F", "major", 131, 165, [
    Ly("melody", "p25", oct=5, att=.02, delay=.35, rev=.15, act=[(0, .7), (.85, .9)], gain=.9),
    Ly("melody", "p25", oct=5, rev=.1, act=[(.7, .85)], duty_curve=[(.7, .25), (.775, .125), (.85, .5)], gain=.9),
    Ly("bass", "tri", oct=2, style="eighths", act=[(.1, .85)], gain=.9),
    Ly("perc", "none", style="rock", nes=True, act=[(.1, .85)], gain=.8),
    Ly("counter", "p125", oct=5, act=[(.4, .85)], gain=.55, rev=.1),
    Ly("pad", "strings", oct=3, act=[(.4, .85)], gain=.5, rev=.5),
    Ly("pad", "choir", oct=4, act=[(.4, .85)], gain=.45, rev=.8),
    Ly("melody", "p125", oct=5, rev=.9, att=.03, act=[(.9, 1.0)], gain_curve=[(.9, 1), (1, .2)], gain=.8),
], leit="spear", rev_mix=.7)

T("ambient_overworld", "B", "major", 138, 240, [
    Ly("melody", "piano", oct=4, rev=.7, gain=.8),
    Ly("bells", "glock", oct=6, prob=.35, rev=.8, gain=.55, pan=.3),
    Ly("chord_bells", "tubular", oct=5, prob=.5, step=1.0, rev=.9, gain=.5, pan=-.3),
    Ly("melody", "sine", oct=5, vib=.004, act=[(.15, 1)], gain=.45, rev=.5, speed=1.0, att=.12, rel=.3),
    Ly("pad", "strings", oct=3, act=[(46 / 240, 1)], pan=-.8, gain=.3, rev=.6),
    Ly("perc", "none", style="rock", nes=False, act=[(.2, 1)], gain=.25),
], leit="waterfall", bpb=3, dpitch=3, ir=4.5)

T("ambient_nether", "C", "minor", 60, 180, [
    Ly("drone", "p50", oct=2, span=2, dis=True, dis_semis=1, rev=.5, gain=.55, att=1.2, rel=2.0),
    Ly("drone", "tri", oct=1, span=2, gain=.8, rev=.2),
    Ly("fx", "none", kind="lava", rate=2.5, rev=.4, gain=.6, pan=-.4),
    Ly("fx", "none", kind="ghast", rate=.3, rev=1.0, gain=.45, pan=.5),
    Ly("melody", "p50", oct=3, speed=.5, dis=1, act=[(.3, 1)], gain=.3, rev=.9, att=.1, rel=1.5),
], leit="core", free=True, jitter=.1, lp=3500, ir=4.5)

T("ambient_end", "E", "minor", 70, 240, [
    Ly("pad", "choir", oct=3, rev=1.0, gain=.7, att=1.2, rel=1.2),
    Ly("melody", "piano", oct=3, lowcut=True, rev=.6, gain=.7, speed=1.0),
    Ly("drone", "sine", oct=1, span=4, gain=.8, att=2.0, rel=2.0, rev=.2),
    Ly("melody", "strings", oct=5, harm=2, delay_beats=.5, rev=1.0, delay=.4, gain=.4, att=.5, act=[(.15, 1)]),
    Ly("bells", "glock", oct=4, prob=.3, rev=1.0, delay=.4, gain=.7),
], leit="waterfall", meter=[(9, 4)], bpb=3, ir=6.0)

# ---------------------------------------------------------------- 5-17 aspect themes
T("aspect_inferno", "G", "minor", 263, ASPECT_DUR, [
    Ly("melody", "p25", oct=5, gain=.9),
    Ly("bass", "tri", oct=2, style="drive", gain=.9),
    Ly("perc", "none", style="drive", nes=True, gain=.7),
    Ly("perc", "none", style="metal", step=.5, gain=.5),
    Ly("melody", "trumpet", oct=5, act=[(.2, 1)], gain=.55, rev=.2),
    Ly("stab", "brass", oct=4, act=[(.25, 1)], gain=.6),
    Ly("pad", "choir", oct=4, act=[(.5, 1)], gain=.4, rev=.6),
    Ly("pad", "strings", oct=3, act=[(.2, 1)], gain=.4, rev=.3),
    Ly("arp", "p125", oct=5, step=.5, act=[(.1, 1)], gain=.4),
    Ly("counter", "trumpet", oct=5, act=[(.6, 1)], gain=.4),
], leit="spear", bpb=2)

T("aspect_tide", "E", "minor", 70, ASPECT_DUR, [
    Ly("pad", "choir", oct=3, rev=1.0, gain=.65, att=1.0),
    Ly("bells", "glock", oct=4, prob=.4, rev=1.0, gain=.6),
    Ly("melody", "piano", oct=4, rev=.8, gain=.75),
    Ly("perc", "none", style="timp", nes=False, act=[(.3, 1)], gain=.6),
    Ly("chord_bells", "tubular", oct=5, prob=.5, step=1.0, rev=.9, gain=.45),
    Ly("melody", "strings", oct=5, harm=2, rev=1.0, delay=.4, gain=.4, act=[(.2, 1)]),
    Ly("perc", "none", style="rock", nes=False, act=[(.5, 1)], gain=.35),
], leit="waterfall", meter=[(9, 4)], bpb=3, ir=5.0)

T("aspect_tempest", "C", "minor", (150, 180), ASPECT_DUR, [
    Ly("melody", "p25", oct=5, lfo=6.0, lfo_depth=.17, gain=.9),
    Ly("counter", "p125", oct=5, act=[(.15, 1)], gain=.5),
    Ly("bass", "tri", oct=2, style="drive", gain=.9),
    Ly("perc", "none", style="metal", step=.5, gain=.7),
    Ly("perc", "none", style="drive", nes=False, gain=.6),
    Ly("stab", "brass", oct=4, act=[(.3, 1)], gain=.55),
], leit="spear")

T("aspect_rift", "D", "minor", 66, ASPECT_DUR, [
    Ly("drone", "sine", oct=2, span=2, moving=False, rev=.8, gain=.8, att=1.0, rel=1.5),
    Ly("drone", "sine", oct=3, span=3, rev=.9, gain=.4, att=1.0, rel=1.5),
    Ly("melody", "piano", oct=3, speed=.5, rev=1.0, gain=.7),
    Ly("glitch", "p25", oct=5, min=0, max=2, rev=.3, gain=.45),
    Ly("fx", "none", kind="click", rate=.8, gain=.4, rev=.2),
], leit="core", free=True, jitter=.12, ir=4.5)

T("aspect_vitality", "D", "major", 110, ASPECT_DUR, [
    Ly("melody", "piano", oct=4, rev=.4, gain=.8),
    Ly("pad", "strings", oct=3, act=[(.15, 1)], gain=.5, rev=.4),
    Ly("bells", "glock", oct=6, prob=.5, rev=.5, gain=.5, pan=.3),
    Ly("melody", "sine", oct=5, vib=.004, harm=2, act=[(.3, 1)], gain=.4, rev=.3, att=.1),
    Ly("bass", "tri", oct=2, style="waltz", gain=.8),
    Ly("perc", "none", style="rock", nes=False, act=[(.2, 1)], gain=.5),
], leit="spear", bpb=3, dpitch=3)

T("aspect_war", "Bb", "minor", 130, ASPECT_DUR, [
    Ly("melody", "p25", oct=5, gain=.85),
    Ly("melody", "p125", oct=5, harm=2, act=[(.1, 1)], gain=.5),
    Ly("bass", "tri", oct=2, style="drive", gain=.9),
    Ly("perc", "none", style="drive", nes=False, gain=.75),
    Ly("perc", "none", style="timp", nes=False, gain=.5),
    Ly("melody", "horn", oct=4, act=[(.25, 1)], gain=.55, rev=.3),
    Ly("pad", "choir", oct=4, act=[(.5, 1)], gain=.4, rev=.6),
    Ly("arp", "strings", oct=4, step=.5, gain=.35, rev=.2),
], leit="spear")

T("aspect_cosmos", "A", "major", 60, ASPECT_DUR, [
    Ly("melody", "celesta", oct=5, speed=.5, rev=1.0, gain=.7),
    Ly("pad", "choir", oct=3, rev=1.0, gain=.55, att=1.2),
    Ly("drone", "sine", oct=1, span=4, gain=.8, att=2.0, rel=2.0),
    Ly("bells", "piano", oct=4, prob=.25, rev=.8, gain=.55),
    Ly("melody", "strings", oct=5, harm=2, act=[(.4, 1)], gain=.35, rev=1.0, delay=.4, att=.5),
], leit="spear", bpb=3, free=True, jitter=.08, ir=5.0)

T("aspect_fortune", "Ab", "major", 95.5, ASPECT_DUR, [
    Ly("melody", "p50", oct=5, vib=.004, gain=.8),
    Ly("pad", "strings", oct=3, att=.5, gain=.5, rev=.4),
    Ly("chord_bells", "piano", oct=4, prob=.8, step=.5, gain=.5, rev=.3),
    Ly("bass", "pluck", oct=3, style="half", gain=.7),
    Ly("arp", "pluck", oct=4, step=.5, act=[(.2, 1)], gain=.35),
    Ly("bells", "glock", oct=6, prob=.4, gain=.45, rev=.5),
    Ly("bass", "tri", oct=2, style="quarters", gain=.7),
    Ly("counter_motif", "clarinet", oct=4, harm=2, act=[(.4, 1)], gain=.5),
    Ly("perc", "none", style="rock", nes=False, act=[(.15, 1)], gain=.55),
], leit="spear")

T("aspect_cloud", "F", "major", 102, ASPECT_DUR, [
    Ly("melody", "vibes", oct=5, gain=.85, rev=.5),
    Ly("bells", "pluck", oct=6, prob=.4, gain=.4),
    Ly("chord_bells", "tubular", oct=5, prob=.6, step=1.0, gain=.45, rev=.7),
    Ly("arp", "piano", oct=4, step=.5, gain=.35, rev=.4),
    Ly("bass", "pluck", oct=3, style="half", gain=.7),
    Ly("pad", "strings", oct=3, att=.5, gain=.5, rev=.4),
    Ly("melody", "p50", oct=5, act=[(.25, 1)], gain=.55, vib=.003),
    Ly("perc", "none", style="rock", nes=False, act=[(.15, 1)], gain=.55),
], leit="spear")

T("aspect_winter", "E", "minor", 122, ASPECT_DUR, [
    Ly("melody", "piano", oct=4, rev=.9, gain=.85),
    Ly("melody", "strings", oct=4, harm=2, act=[(.2, 1)], gain=.45, rev=.6),
    Ly("chord_bells", "tubular", oct=5, prob=.6, step=1.0, gain=.45, rev=.8),
    Ly("pad", "strings", oct=3, gain=.45, rev=.5),
    Ly("perc", "none", style="rock", nes=False, act=[(.3, 1)], gain=.55),
], leit="spear")

T("aspect_shadow", "Gb", "minor", 66, ASPECT_DUR, [
    Ly("drone", "sine", oct=2, span=2, rev=.8, gain=.8, att=1.0, rel=1.5),
    Ly("melody", "cello", oct=3, speed=.5, rev=.7, gain=.7),
    Ly("glitch", "p25", oct=5, min=0, max=2, gain=.4, rev=.3),
], leit="core", bpb=3, free=True, jitter=.1, ir=4.5)

T("aspect_storm", "F", "minor", 130, ASPECT_DUR, [
    Ly("melody", "p25", oct=4, detune=10, lfo=.4, lfo_depth=.12, gain=.85),
    Ly("bass", "tri", oct=2, style="drive", gain=.85),
    Ly("pad", "choir", oct=2, gain=.5, rev=.3),
    Ly("pad", "strings", oct=2, gain=.4, rev=.2),
    Ly("perc", "none", style="drive", nes=True, gain=.75),
    Ly("perc", "none", style="metal", step=.25, pan=-.7, gain=.4),
    Ly("perc", "none", style="metal", step=.5, pan=.7, gain=.4),
], leit="metal")

T("aspect_base", "A", "minor", 80, ASPECT_DUR, [
    Ly("melody", "p50", oct=4, vib=.005, speed=.5, rev=.3, gain=.7),
    Ly("bells", "musicbox", oct=5, prob=.5, rev=.4, gain=.55),
    Ly("bass", "tri", oct=2, style="sustain", hold=.5, gain=.7),
], leit="spear")

# ---------------------------------------------------------------- 18-44 events (7 phases each)
EV = dict(leit="spear")

# Ninth Sky (F major -> D minor -> C major)
T("event_ninth_sky_phase1", "F", "major", 80, EVENT_DUR, [
    Ly("melody", "vibes", oct=5, speed=.5, rev=.6, gain=.8),
    Ly("fx", "none", kind="chimes", rate=1.4, rev=.7, gain=.5),
], leit="spear")
T("event_ninth_sky_phase2", "F", "major", 90, EVENT_DUR, [
    Ly("melody", "vibes", oct=5, rev=.6, gain=.7),
    Ly("melody", "piano", oct=4, rev=.5, gain=.7),
    Ly("chord_bells", "tubular", oct=5, prob=.7, step=1.0, rev=.8, gain=.5),
    Ly("fx", "none", kind="chimes", rate=1.0, rev=.7, gain=.4),
], leit="spear")
T("event_ninth_sky_phase3", "F", "major", 100, EVENT_DUR, [
    Ly("melody", "vibes", oct=5, rev=.5, gain=.6),
    Ly("glitch", "p25", oct=5, min=1, max=3, gain=.5, rev=.3),
    Ly("perc", "none", style="sparse", nes=True, gain=.7),
    Ly("pad", "strings", oct=3, gain=.4, rev=.5),
    Ly("fx", "none", kind="click", rate=1.2, gain=.4),
], leit="spear")
T("event_ninth_sky_phase4", "D", "minor", 130, EVENT_DUR, [
    Ly("melody", "p25", oct=5, gain=.85),
    Ly("stab", "brass", oct=4, gain=.6),
    Ly("bass", "tri", oct=2, style="drive", gain=.85),
    Ly("perc", "none", style="drive", nes=False, gain=.7),
    Ly("perc", "none", style="timp", nes=False, gain=.5),
], leit="spear")
T("event_ninth_sky_phase5", "D", "minor", 140, EVENT_DUR, [
    Ly("melody", "trumpet", oct=5, gain=.75),
    Ly("melody", "brass", oct=4, gain=.6),
    Ly("melody", "p25", oct=5, gain=.5),
    Ly("pad", "choir", oct=4, gain=.5, rev=.5),
    Ly("stab", "brass", oct=4, gain=.6),
    Ly("bass", "tri", oct=2, style="drive", gain=.85),
    Ly("perc", "none", style="drive", nes=False, gain=.75),
    Ly("perc", "none", style="timp", nes=False, gain=.6),
], leit="spear")
T("event_ninth_sky_phase6", "D", "minor", 150, EVENT_DUR, [
    Ly("melody", "p25", oct=5, duty_curve=[(0, .25), (.5, .125), (1, .5)], gain=.8),
    Ly("melody", "trumpet", oct=5, gain=.55),
    Ly("melody", "brass", oct=4, gain=.5),
    Ly("pad", "choir", oct=4, gain=.5, rev=.5),
    Ly("pad", "strings", oct=3, gain=.4, rev=.4),
    Ly("arp", "p125", oct=5, step=.25, gain=.35),
    Ly("stab", "brass", oct=4, gain=.6),
    Ly("bass", "tri", oct=2, style="drive", gain=.85),
    Ly("perc", "none", style="drive", nes=False, gain=.8),
    Ly("perc", "none", style="metal", step=.25, gain=.4),
    Ly("perc", "none", style="timp", nes=False, gain=.6),
], leit="spear")
T("event_ninth_sky_phase7", "C", "major", 120, EVENT_DUR, [
    Ly("pad", "choir", oct=3, rev=1.0, gain=.6, att=.8),
    Ly("melody", "piano", oct=4, rev=.8, gain=.7),
    Ly("bells", "glock", oct=6, prob=.5, rev=1.0, gain=.55),
    Ly("pad", "strings", oct=3, gain=.4, rev=.7),
], leit="spear", loop=False, fadeout=5.0, ir=5.5, tail=4)

# Frozen Eclipse (E minor -> G major)
T("event_frozen_eclipse_phase1", "E", "minor", 70, EVENT_DUR, [
    Ly("melody", "piano", oct=4, rev=1.0, gain=.8),
    Ly("fx", "none", kind="chimes", rate=1.3, rev=.8, gain=.45),
], leit="waterfall", ir=4.5)
T("event_frozen_eclipse_phase2", "E", "minor", 60, EVENT_DUR, [
    Ly("melody", "horn", oct=3, rev=.5, gain=.75),
    Ly("bass", "tri", oct=2, style="sustain", gain=.8),
    Ly("pad", "strings", oct=3, gain=.35, rev=.6),
], leit="waterfall", ir=4.0)
T("event_frozen_eclipse_phase3", "E", "minor", 110, EVENT_DUR, [
    Ly("melody", "p25", oct=5, gain=.75),
    Ly("perc", "none", style="drive", nes=False, gain=.75),
    Ly("perc", "none", style="timp", nes=False, gain=.6),
    Ly("bass", "tri", oct=2, style="drive", gain=.85),
], leit="spear")
T("event_frozen_eclipse_phase4", "E", "minor", 100, EVENT_DUR, [
    Ly("pad", "choir", oct=4, rev=.7, gain=.55),
    Ly("melody", "trumpet", oct=5, gain=.75, rev=.3),
    Ly("stab", "brass", oct=4, gain=.5),
    Ly("bass", "tri", oct=2, style="quarters", gain=.8),
    Ly("perc", "none", style="rock", nes=False, gain=.65),
], leit="spear")
T("event_frozen_eclipse_phase5", "E", "minor", 150, EVENT_DUR, [
    Ly("melody", "p25", oct=5, speed=2.0, dis=1, gain=.8),
    Ly("arp", "p125", oct=5, step=.25, gain=.4),
    Ly("bass", "tri", oct=2, style="drive", gain=.85),
    Ly("perc", "none", style="metal", step=.25, gain=.8),
    Ly("perc", "none", style="drive", nes=True, gain=.6),
], leit="spear")
T("event_frozen_eclipse_phase6", "G", "major", 80, EVENT_DUR, [
    Ly("pad", "choir", oct=3, rev=1.0, gain=.55, att=.8),
    Ly("melody", "piano", oct=4, rev=.9, gain=.75),
    Ly("bells", "glock", oct=6, prob=.5, rev=1.0, gain=.5),
], leit="waterfall", ir=5.0)
T("event_frozen_eclipse_phase7", "G", "major", 90, EVENT_DUR, [
    Ly("melody", "musicbox", oct=5, rev=.4, gain=.8),
    Ly("chord_bells", "musicbox", oct=4, prob=.7, step=.5, rev=.4, gain=.45),
], leit="spear", loop=False, fadeout=5.0, tail=4)

# Shadows Descent (F# minor, core/premonition leitmotif = inverted motif)
T("event_shadows_descent_phase1", "Gb", "minor", 50, EVENT_DUR, [
    Ly("drone", "sine", oct=2, span=2, rev=.8, gain=.8, att=1.2, rel=1.5),
    Ly("drone", "sine", oct=3, span=3, dis=True, dis_semis=1, rev=.8, gain=.35, att=1.2, rel=1.5),
], leit="core", free=True, ir=4.5)
T("event_shadows_descent_phase2", "Gb", "minor", 70, EVENT_DUR, [
    Ly("drone", "sine", oct=2, span=2, rev=.7, gain=.7, att=1.0, rel=1.5),
    Ly("glitch", "p25", oct=5, min=1, max=3, gain=.5, rev=.3),
    Ly("perc", "none", style="sparse", nes=True, gain=.6),
], leit="core")
T("event_shadows_descent_phase3", "Gb", "minor", 85, EVENT_DUR, [
    Ly("drone", "sine", oct=2, span=2, dis=True, gain=.7, rev=.7, att=1.0, rel=1.5),
    Ly("perc", "none", style="metal", step=.25, gain_curve=[(0, .15), (1, 1.0)], gain=.8),
    Ly("bass", "tri", oct=2, style="sustain", gain_curve=[(0, .2), (1, 1.0)], gain=.8),
    Ly("melody", "p125", oct=5, gain_curve=[(0, 0), (.5, .3), (1, .8)], gain=.6, rev=.4),
], leit="core")
T("event_shadows_descent_phase4", "Gb", "minor", 120, EVENT_DUR, [
    Ly("melody", "p125", oct=5, gain=.8),
    Ly("bass", "tri", oct=2, style="drive", gain=.85),
    Ly("perc", "none", style="metal", step=.25, gain=.7),
    Ly("perc", "none", style="drive", nes=True, gain=.6),
    Ly("arp", "p125", oct=5, step=.25, gain=.3),
], leit="core")
T("event_shadows_descent_phase5", "Gb", "minor", 90, EVENT_DUR, [
    Ly("melody", "brass", oct=4, gain=.8),
    Ly("pad", "choir", oct=3, rev=.6, gain=.55),
    Ly("stab", "brass", oct=3, gain=.5),
    Ly("bass", "tri", oct=2, style="quarters", gain=.8),
    Ly("perc", "none", style="timp", nes=False, gain=.7),
], leit="core")
T("event_shadows_descent_phase6", "Gb", "minor", 130, EVENT_DUR, [
    Ly("melody", "p125", oct=5, dis=1, gain=.75),
    Ly("melody", "brass", oct=4, gain=.5),
    Ly("pad", "choir", oct=3, gain=.45, rev=.5),
    Ly("drone", "sine", oct=2, span=2, dis=True, gain=.6, rev=.5, att=1.0, rel=1.0),
    Ly("bass", "tri", oct=2, style="drive", gain=.85),
    Ly("perc", "none", style="metal", step=.25, gain=.8),
    Ly("perc", "none", style="drive", nes=True, gain=.7),
    Ly("glitch", "p25", oct=5, min=2, max=4, gain=.4),
], leit="core", crush=5, hold=3)
T("event_shadows_descent_phase7", "Gb", "minor", 60, EVENT_DUR, [
    Ly("drone", "sine", oct=2, span=2, gain=.8, gain_curve=[(0, 1), (.8, .25), (1, 0)], rev=.8, att=1.0, rel=1.5),
    Ly("bells", "glock", oct=5, prob=.3, rev=1.0, gain=.45, gain_curve=[(0, 1), (.8, .2), (1, 0)]),
], leit="core", free=True, loop=False, fadeout=10.0, ir=5.0, tail=5)

# Tempest's Fury (F minor -> F major)
T("event_tempests_fury_phase1", "F", "minor", 80, EVENT_DUR, [
    Ly("melody", "p25", oct=4, detune=10, speed=.5, gain=.7, rev=.3),
    Ly("fx", "none", kind="thunder", rate=.6, rev=.6, gain=.6),
], leit="metal")
T("event_tempests_fury_phase2", "F", "minor", 100, EVENT_DUR, [
    Ly("arp", "p125", oct=5, step=.25, gain=.45),
    Ly("bass", "tri", oct=2, style="drive", gain=.85),
    Ly("melody", "p25", oct=4, detune=10, act=[(.3, 1)], gain=.7),
    Ly("fx", "none", kind="thunder", rate=.4, rev=.6, gain=.5),
], leit="metal")
T("event_tempests_fury_phase3", "F", "minor", 120, EVENT_DUR, [
    Ly("melody", "p25", oct=4, detune=10, gain=.8),
    Ly("bass", "tri", oct=2, style="drive", gain=.85),
    Ly("perc", "none", style="metal", step=.5, gain=.7),
    Ly("fx", "none", kind="wind", rate=1.0, rev=.5, gain=.5),
], leit="metal")
T("event_tempests_fury_phase4", "F", "minor", 140, EVENT_DUR, [
    Ly("melody", "p25", oct=4, detune=10, lfo=.4, gain=.85),
    Ly("bass", "tri", oct=2, style="drive", gain=.85),
    Ly("perc", "none", style="drive", nes=True, gain=.75),
    Ly("perc", "none", style="metal", step=.25, pan=-.7, gain=.4),
    Ly("perc", "none", style="metal", step=.5, pan=.7, gain=.4),
    Ly("stab", "brass", oct=4, gain=.5),
], leit="metal")
T("event_tempests_fury_phase5", "F", "minor", 110, EVENT_DUR, [
    Ly("melody", "brass", oct=4, gain=.8),
    Ly("pad", "choir", oct=3, gain=.6, rev=.6),
    Ly("stab", "brass", oct=3, gain=.6),
    Ly("bass", "tri", oct=2, style="quarters", gain=.8),
    Ly("perc", "none", style="timp", nes=False, gain=.8),
    Ly("perc", "none", style="drive", nes=False, gain=.5),
], leit="metal")
T("event_tempests_fury_phase6", "F", "minor", 160, EVENT_DUR, [
    Ly("melody", "p25", oct=4, detune=10, duty_curve=[(0, .125), (.5, .5), (1, .125)], lfo=1.5, gain=.8),
    Ly("melody", "brass", oct=4, gain=.5),
    Ly("arp", "p125", oct=5, step=.25, gain=.4),
    Ly("pad", "choir", oct=3, gain=.45, rev=.5),
    Ly("bass", "tri", oct=2, style="drive", gain=.85),
    Ly("perc", "none", style="drive", nes=True, gain=.8),
    Ly("perc", "none", style="metal", step=.25, gain=.6),
    Ly("fx", "none", kind="thunder", rate=.7, rev=.5, gain=.5),
], leit="metal", crush=5, hold=3)
T("event_tempests_fury_phase7", "F", "major", 72, EVENT_DUR, [
    Ly("melody", "piano", oct=4, rev=.9, gain=.8),
    Ly("pad", "choir", oct=3, rev=1.0, gain=.55, att=.8),
    Ly("bells", "glock", oct=6, prob=.5, rev=1.0, gain=.5),
    Ly("pad", "strings", oct=3, gain=.4, rev=.7),
], leit="spear", loop=False, fadeout=6.0, ir=5.5, tail=5)

# ---------------------------------------------------------------- 45-51 state / action tracks
T("heart_dormant", "C", "minor", 115, 30, [
    Ly("melody", "p50", oct=4, vib=.006, speed=.5, rev=.4, gain=.7),
    Ly("bass", "tri", oct=2, style="sustain", hold=.7, gain=.7),
    Ly("perc", "none", style="heart", nes=True, gain=.9, gain_curve=[(0, 1), (1, .25)]),
], leit="spear", bpb=3, lp=5000)

T("heart_awakened", "C", "major", 96, 15, [
    Ly("harmonics", "p25", oct=3, vel=.7, att=.03, rel=.2),
    Ly("pad", "choir", oct=4, rev=1.0, gain=.55, att=1.0),
    Ly("pad", "strings", oct=3, rev=.7, gain=.4, att=.8),
    Ly("melody", "p25", oct=5, act=[(.4, 1)], gain=.5, rev=.6),
], leit="spear", ir=4.0)

T("heart_critical", "C", "minor", 148, 20, [
    Ly("melody", "p125", oct=5, bend=2, gain=.85),
    Ly("bass", "tri", oct=2, style="drive", gain=.8),
    Ly("perc", "none", style="accel", nes=True, gain=.7),
    Ly("drone", "p125", oct=3, span=2, dis=True, dis_semis=13, gain=.35, att=.05, rel=.1),
], leit="spear")

_pent = [0, 1, 2, 4, 5, 7, 8, 9, 11, 12]
T("tier_up", "C", "major", 120, 5, [
    Ly("seq", "p25", oct=4, items=[(d, .25) for d in [0, 1, 2, 4, 5, 7, 8, 9]] + [(11, 3.0)], gain=.9),
    Ly("seq", "glock", oct=5, start=.125, items=[(d, .25) for d in [0, 1, 2, 4, 5, 7, 8, 9]] + [(11, 3.0)], rev=1.0, gain=.7),
], loop=False, fadeout=.6, ir=2.5, tail=3)

T("aspect_shift", "F", "minor", 131, 10, [
    Ly("melody", "p25", oct=5, duty_curve=[(0, .25), (.4, .125)], gain_curve=[(0, 1), (.35, 1), (.5, 0)], gain=.9),
    Ly("drone", "sine", oct=2, span=2, gain=.9, gain_curve=[(.3, 0), (.45, .8), (.75, .8), (1, .3)], att=1.0, rel=1.0, rev=.5),
    Ly("melody", "p125", oct=5, shift=5, gain_curve=[(.55, 0), (.75, 1), (1, 1)], gain=.8, rev=.4),
], leit="spear", loop=False, fadeout=.5, ir=3.0)

_comb = dict(leit="spear")
T("combat_intense", "D", "minor", 183, 30, [
    Ly("bass", "tri", oct=2, style="drive", gain=.9),
    Ly("perc", "none", style="metal", step=.5, nes=True, gain=.7),
    Ly("melody", "p25", oct=5, act=[(1 / 3, 1)], gain=.85),
    Ly("perc", "none", style="rock", nes=False, act=[(1 / 3, 1)], gain=.7),
    Ly("counter", "p125", oct=5, act=[(2 / 3, 1)], gain=.6),
    Ly("stab", "brass", oct=4, act=[(2 / 3, 1)], gain=.6),
], leit="spear", stems=True)

T("victory", "C", "major", 120, 10, [
    Ly("seq", "p25", oct=5, gain=.85, items=[(4, .5), (4, .5), (4, .5), (7, 1.5), (5, .5), (5, .5), (5, .5), (9, 1.5), (7, .75), (9, .25), (11, .5), (9, .5), (7, 1.0), (4, 1.0), (7, 5.0)]),
    Ly("pad", "choir", oct=3, rev=1.0, gain=.55, att=.2),
    Ly("pad", "strings", oct=3, rev=.7, gain=.45, att=.2),
    Ly("bells", "glock", oct=6, prob=.8, rev=1.0, gain=.5),
], leit="spear", loop=False, fadeout=1.0, ir=3.5, tail=4)

T("defeat", "A", "minor", 75, 8, [
    Ly("seq", "p50", oct=4, vib=.008, gain=.8, items=[(4, 1.0), (3, 1.0), (2, 1.0), (1, 1.0), (0, 4.0)]),
    Ly("fx", "none", kind="click", rate=.8, gain=.3),
], leit="spear", loop=False, fadeout=3.0, ir=2.5, tail=2)
