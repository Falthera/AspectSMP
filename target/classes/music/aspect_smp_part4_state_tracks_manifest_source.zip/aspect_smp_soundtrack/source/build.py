"""Render every track to out/*.ogg with loudness targets, loop metadata and a manifest."""
import json
import os
import re
import subprocess
import sys
import tempfile
import time
from multiprocessing import Pool

import numpy as np
from scipy.io import wavfile

sys.path.insert(0, os.path.dirname(__file__))
from composer import compose  # noqa
from engine import SR  # noqa
from tracks import TRACKS  # noqa

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out")
SFX = {"tier_up", "aspect_shift", "victory", "defeat"}


def measure_lufs(x):
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "m.wav")
        wavfile.write(p, SR, x.astype(np.float32))
        r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", p, "-af", "ebur128=framelog=quiet", "-f", "null", "-"],
                           capture_output=True, text=True)
    m = re.findall(r"I:\s+(-?[\d.]+)\s+LUFS", r.stderr)
    return float(m[-1]) if m else None


def normalize(x, target):
    x = x - x.mean(axis=0, keepdims=True) * 0.0
    for _ in range(3):
        lufs = measure_lufs(x)
        if lufs is None:
            break
        g = 10 ** ((target - lufs) / 20)
        x = x * g
        pk = np.abs(x).max()
        if pk > 0.89:  # ~ -1 dBFS ceiling, memoryless soft limiter keeps loop seams intact
            x = np.tanh(x / 0.95) * 0.95
        if abs(measure_lufs(x) - target) < 0.4:
            break
    return x


def encode(x, path, loop_samples=None, title=""):
    cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-f", "f32le", "-ar", str(SR), "-ac", "2", "-i", "-",
           "-c:a", "libvorbis", "-q:a", "6", "-ar", str(SR), "-metadata", f"TITLE={title}"]
    if loop_samples:
        cmd += ["-metadata", "LOOPSTART=0", "-metadata", f"LOOPLENGTH={loop_samples}"]
    cmd.append(path)
    subprocess.run(cmd, input=x.astype(np.float32).tobytes(), check=True)


def render_one(args):
    cfg, suffix, layers = args
    t0 = time.time()
    name = cfg["name"] + suffix
    short = cfg["name"].replace("mus_aspectsmp_", "")
    audio, info = compose(cfg, layers=layers)
    target = -20.0 if short in SFX else -14.0
    audio = normalize(audio, target)
    loop = cfg.get("loop", True)
    path = os.path.join(OUT, name + ".ogg")
    encode(audio, path, loop_samples=info["samples"] if loop else None, title=name)
    seam = None
    if loop:
        d_seam = float(np.abs(audio[0] - audio[-1]).max())
        d_typ = float(np.abs(np.diff(audio, axis=0)).mean() + 1e-9)
        seam = d_seam / d_typ
    return dict(file=name + ".ogg", seconds=round(info["seconds"], 2), samples=info["samples"], loop=loop,
                loop_start=0 if loop else None, loop_length=info["samples"] if loop else None,
                target_lufs=target, peak=round(float(np.abs(audio).max()), 3), seam_ratio=None if seam is None else round(seam, 2),
                render_s=round(time.time() - t0, 1))


def jobs(selected=None):
    out = []
    for cfg in TRACKS:
        short = cfg["name"].replace("mus_aspectsmp_", "")
        if selected and short not in selected:
            continue
        out.append((cfg, "", None))
        if cfg.get("stems"):
            L = cfg["layers"]
            groups = [L[:2], L[:4], L[:6]]
            for k, g in enumerate(groups, start=1):
                full = [dict(l, act=None) for l in g]
                out.append((cfg, f"_layer{k}", full))
    return out


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    sel = set(sys.argv[1:]) or None
    js = jobs(sel)
    procs = int(os.environ.get("PROCS", "4"))
    t0 = time.time()
    with Pool(procs) as p:
        results = []
        for r in p.imap_unordered(render_one, js):
            print(f"{r['file']:62s} {r['seconds']:7.2f}s peak={r['peak']:.2f} seam={r['seam_ratio']} ({r['render_s']}s)", flush=True)
            results.append(r)
    results.sort(key=lambda r: r["file"])
    mpath = os.path.join(OUT, "manifest.json") if not sel else os.path.join(OUT, "manifest_partial.json")
    json.dump(results, open(mpath, "w"), indent=1)
    print("done", len(results), "files in", round(time.time() - t0), "s")
