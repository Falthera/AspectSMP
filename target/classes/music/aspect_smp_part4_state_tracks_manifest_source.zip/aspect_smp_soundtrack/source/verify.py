import glob, json, os, re, subprocess, sys
import numpy as np

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out")
man = {m["file"]: m for m in json.load(open(os.path.join(OUT, "manifest.json")))}
SR = 44100
bad = []
rows = []
for f in sorted(glob.glob(os.path.join(OUT, "*.ogg"))):
    name = os.path.basename(f)
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", f, "-f", "f32le", "-ac", "2", "-ar", str(SR), "-"], capture_output=True).stdout
    x = np.frombuffer(raw, dtype=np.float32).reshape(-1, 2)
    r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", f, "-af", "ebur128=framelog=quiet", "-f", "null", "-"], capture_output=True, text=True)
    lufs = float(re.findall(r"I:\s+(-?[\d.]+)\s+LUFS", r.stderr)[-1])
    m = man[name]
    sec = len(x) / SR
    # seam: jump from last->first sample compared with the largest ordinary sample-to-sample step in the file
    d = np.abs(np.diff(x, axis=0)).max(axis=1)
    p999 = float(np.percentile(d, 99.9))
    mx = float(d.max())
    seam = float(np.abs(x[0] - x[-1]).max())
    # silence check: longest run of windows below -60 dBFS RMS (200 ms windows)
    w = int(0.2 * SR)
    n = len(x) // w
    rms = np.sqrt((x[: n * w].reshape(n, w, 2) ** 2).mean(axis=(1, 2)))
    quiet = rms < 10 ** (-60 / 20)
    run = best = 0
    for q in quiet:
        run = run + 1 if q else 0
        best = max(best, run)
    sil = best * 0.2
    status = "ok"
    if abs(lufs - m["target_lufs"]) > 1.0:
        status = "LUFS"
    if m["loop"] and seam > max(p999, 1e-6) * 2.0:
        status = "SEAM"
    if np.abs(x).max() >= 0.999:
        status = "CLIP"
    if status != "ok":
        bad.append((name, status))
    rows.append((name, round(sec, 2), round(lufs, 1), m["target_lufs"], round(float(np.abs(x).max()), 2), m["loop"],
                 round(seam, 4), round(p999, 4), round(mx, 4), round(sil, 1), status))
    print(f"{name:55s} {sec:7.2f}s LUFS {lufs:6.1f}/{m['target_lufs']:.0f} pk {np.abs(x).max():.2f} loop={m['loop']!s:5} seam={seam:.4f} p99.9={p999:.4f} max={mx:.4f} longest_quiet={sil:.1f}s {status}")
print("files:", len(rows), "problems:", bad)
